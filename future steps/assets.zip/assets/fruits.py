import pygame

images = [
    pygame.image.load('assets/img/apple1.png'),
    pygame.image.load('assets/img/apple2.png'),
    pygame.image.load('assets/img/apple3.png'),
    pygame.image.load('assets/img/banana.png'),
    pygame.image.load('assets/img/body.png'),
    pygame.image.load('assets/img/bomb.png'),
    pygame.image.load('assets/img/head.png'),
    pygame.image.load('assets/img/orange.png'),
    pygame.image.load('assets/img/pear1.png'),
    pygame.image.load('assets/img/pineapple.png'),
    pygame.image.load('assets/img/plum.png'),
    pygame.image.load('assets/img/skull.png'),
    pygame.image.load('assets/img/strawberry.png'),
    pygame.image.load('assets/img/watermelon.png')
]

good = [
    pygame.image.load('assets/img/apple1.png'),
    pygame.image.load('assets/img/apple2.png'),
    pygame.image.load('assets/img/apple3.png'),
    pygame.image.load('assets/img/banana.png'),
    pygame.image.load('assets/img/body.png'),
    pygame.image.load('assets/img/orange.png'),
    pygame.image.load('assets/img/pear1.png'),
    pygame.image.load('assets/img/pineapple.png'),
    pygame.image.load('assets/img/plum.png'),
    pygame.image.load('assets/img/strawberry.png'),
    pygame.image.load('assets/img/watermelon.png')
]

bad = [
    pygame.image.load('assets/img/bomb.png'),
    pygame.image.load('assets/img/head.png'),
    pygame.image.load('assets/img/skull.png')
]