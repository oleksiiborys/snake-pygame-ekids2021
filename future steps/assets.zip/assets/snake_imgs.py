import pygame


heads = [pygame.image.load('assets/img/head_blue.png'),
         pygame.image.load('assets/img/head_cyan.png'),
         pygame.image.load('assets/img/head_green.png'),
         pygame.image.load('assets/img/head_grey.png'),
         pygame.image.load('assets/img/head_purple.png'),
         pygame.image.load('assets/img/head_red.png'),
         pygame.image.load('assets/img/head_yellow.png')]

bodies = [pygame.image.load('assets/img/body_blue.png'),
          pygame.image.load('assets/img/body_cyan.png'),
          pygame.image.load('assets/img/body_green.png'),
          pygame.image.load('assets/img/body_grey.png'),
          pygame.image.load('assets/img/body_purple.png'),
          pygame.image.load('assets/img/body_red.png'),
          pygame.image.load('assets/img/body_yellow.png')]